function savethese(filename,j,XX,ESS)
save(sprintf('%s_id%i',filename,j));

