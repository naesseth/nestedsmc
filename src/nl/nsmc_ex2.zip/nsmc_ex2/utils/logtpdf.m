function lp = logtpdf(x, nu, lambda)
% LOGTPDF  Computes the logarithm of the PDF for a Student's t-distribution
%   Q = LOGTPDF(X, NU, LAMBDA) computes the value of the monovariate
%   Student's t-PDF with NU degrees of freedom and precision LAMBDA at the
%   values in X. 
%
%   Fredrik Lindsten, 2015-01-28
%   lindsten@isy.liu.se

const = gammaln(nu/2+1/2) - gammaln(nu/2) + 1/2*log(lambda/(pi*nu));
lp = -(nu+1)/2*log(1 + lambda*x.^2/nu) + const;
