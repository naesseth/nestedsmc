/*
 * systematic_resampling.c - MEX routine for systematic resampling
 *
 * Inputs: 
 *
 * W, N x 1: Normalised weights
 * U, 1 x 1: Uniform [0,1] variable (provided as input to avoid random
 *           number generation within the mex routine)
 * 
 * Outputs:
 * I, N x 1: Indices
 *
 * The calling syntax is:
 *
 *		I = systematic_resampling(W,U)
 *
 * This is a MEX-file for MATLAB.
 */

#include "mex.h"

/* The computational routine */
void sys_resample(double U, double *qw, double *inds, size_t N)
{
    size_t i,k;
    k = 0;
    for (i=0; i<N; i++) {
        while (N*qw[k] < i+U) {
            ++k;
        }
        inds[i] = k+1; /* +1 to get Matlab indexing */
    }
}

/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{    
    double *W;     /* input, (unnormalised) weights, Nx1 vector */
    double U;      /* input, uniform rnd num, scalar */
    size_t N;      /* size of input */
    double *inds;  /* output */
    
    mwSize i;      /* loop variable */
    double Wsum;   /* weight normalisation */
    double *qw;    /* cumulative normalised weights */

    /* check for proper number of arguments */
    if(nrhs!=2) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:nrhs","Two inputs required.");
    }
    if(nlhs!=1) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:nlhs","One output required.");
    }
    /* make sure the first input argument is type double */
    if( !mxIsDouble(prhs[0]) || 
         mxIsComplex(prhs[0])) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:notDouble","Input W must be type double.");
    }
    /* make sure the second input argument is scalar */
    if( !mxIsDouble(prhs[1]) || 
         mxIsComplex(prhs[1]) ||
         mxGetNumberOfElements(prhs[1])!=1) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:notScalar","Input U must be a real scalar in the interval [0,1].");
    }    
    
    /* check that number of columns in second input argument is 1 */
    if(mxGetN(prhs[0])!=1) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:notColumnVector","Input W must be a column vector.");
    }
    
    W = mxGetPr(prhs[0]);       /* create a pointer to the weight vector */    
    U = mxGetScalar(prhs[1]);   /* get the value of the scalar input  */
    N = mxGetM(prhs[0]);        /* get dimensions of the input matrix */

    /* Further input check, U should be in the interval [0,1] */
    if(U >= 1 || U <= 0) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:input","Input U must be in the interval (0,1).");
    }
    
    /* Normalise the weights (and make sure that they are nonnegative) */
    Wsum = 0;
    for (i=0; i<N; ++i) {
        if(W[i] < 0) {
            mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:input","Input W must be nonnegative.");
        }
        Wsum = Wsum + W[i];
    }
    if(Wsum==0) {
        mexErrMsgIdAndTxt("MyToolbox:systematic_resampling:input","Input W must sum to a positive value.");
    }
    
    /* Compute cumulative weight sum */
    qw = mxCalloc(N, sizeof(double));
    qw[0] = W[0]/Wsum;
    for (i=1; i<N; ++i) {
        qw[i] = qw[i-1] + W[i]/Wsum;
    }
    
    /* create the output vector */
    plhs[0] = mxCreateDoubleMatrix((mwSize)N,1,mxREAL);    
    inds = mxGetPr(plhs[0]); /* get a pointer to the real data in the output matrix */

    /* call the computational routine */
    sys_resample(U,qw,inds,N);
}
