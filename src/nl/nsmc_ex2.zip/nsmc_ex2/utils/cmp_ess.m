function [Wght, ess] = cmp_ess(logW)
% logW : [M N], computes ess for each column

M = size(logW,1);
maxlW = max( logW, [], 1 );
wght = exp( bsxfun(@minus, logW, maxlW) );
Wght = bsxfun(@rdivide, wght, sum(wght,1));
ess = 1./(M*sum(Wght.^2,1));
