function [Y,X] = gendata(par)
d = par.d;
delta = par.delta;
nu = par.nu;
sigma = par.sigma;
T = par.T;

% Distance r = 1
%
X = zeros(d,d,T);
Y = zeros(d,d,T);

% Initial state and observation
X(:,:,1) = sigma*randn(d,d);
Y(:,:,1) = X(:,:,1) + trnd(nu,d,d);

% Define distance array
%    1
%  2 3 4
%    5
%

Nv = [-1 0 0 0 1 ; 0 -1 0 1 0]'; % Five neighbours
% D1 = [1 1 0 1 1]'; % Distance to neighbours
% D = zeros(d,d,5);
% for(i = 1:d)
%     for(j = 1:d)
%         % v = (i,j)
%         Nvij = Nv + ones(5,1)*[i j];
%         valid = all(Nvij > 0 & Nvij < d+1,2);
%         D(i,j,:) = D1;
%         D(i,j,~valid) = Inf;
%     end
% end

D = [1 1 0 1 1]'; % Distance to neighbours

for(k = 2:T)
    for(i = 1:d)
        for(j = 1:d)
            % v = (i,j)
            Nvij = Nv + ones(5,1)*[i j];
            valid = all(Nvij > 0 & Nvij < d+1,2);
            w = 1./(D+delta).*valid;
            w = w/sum(w);
            % Select component
            m = catrnd(w);
            u = Nvij(m,:);
            % Simulate state
            X(i,j,k) = X(u(1),u(2),k-1) + sigma*randn(1);
        end
    end
    
    % Simulate measurement
    Y(:,:,k) = X(:,:,k) + trnd(nu,d,d);
end