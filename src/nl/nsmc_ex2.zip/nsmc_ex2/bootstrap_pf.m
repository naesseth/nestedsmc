function [Xhat, X2hat, ess_log] = bootstrap_pf(Y,N,par)

% Extract some parameters
d = par.d;
delta = par.delta;
nu = par.nu;
sigma = par.sigma;
T = par.T;

% Output
Xhat = zeros(d,d,T);
X2hat = zeros(d,d,T);
ess_log = zeros(1,T);

%    1
%  2 3 4
%    5
Nv = [-1 0 0 0 1 ; 0 -1 0 1 0]'; % Five neighbours
D = [1 1 0 1 1]'; % Distance to neighbours


% --- k = 1 ---------------------------------------------------------------
% Simulate from prior
Xcur = sigma*randn(d,d,N); 

% Evaluate weights
logW = sum(sum(logtpdf(bsxfun(@minus, Y(:,:,1), Xcur), nu, 1),1),2); % [1 1 N]
maxlW = max( logW );
wght = exp( logW - maxlW ); % unnormalised
Wght = wght/sum(wght);
ess = 1/(N*sum(Wght.^2,3));
ess_log(1) = ess*N;

% Compute estimate
Xhat(:,:,1) = sum(bsxfun(@times, Xcur, Wght),3);
X2hat(:,:,1) = sum(bsxfun(@times, Xcur.^2, Wght),3);

% --- k > 1 ---------------------------------------------------------------
for(k = 2:T)
    fprintf('PF: %i\n',k);
    % **** RESAMPLING ****
    % Resample if below threshold
    if(~par.ESS_based || ess < par.ESS_threshold)       
        % ind = resampling(Wght(:,i),par.resampling);
        A = systematic_resampling(Wght(:),rand(1));
        logW = 0; % Set log-weights to zero after resampling
    else
        A = 1:N;
    end
    
    Xold = Xcur(:,:,A);
    
    % **** PROPAGATION ****
    for(col = 1:d)
        for(row = 1:d)
            % Simulate from prior
            Nvij = Nv + ones(5,1)*[row col]; % 5-neighbourhood
            valid = all(Nvij > 0 & Nvij < d+1,2);
            mixtureprob = 1./(D+delta).*valid; % Mixture probabilities
            mixtureprob = mixtureprob/sum(mixtureprob);
            % Select components (for all particles at once)
            mixturecomp = catrnd(mixtureprob,N);

            for(m = 1:5) % Loop over 5 possible neighbours
                if(valid(m)) % No point in checking invalid neighbours
                    uinds = mixturecomp == m; % These particles come from mixture component m (with the same u-coordinates)
                    u = Nvij(m,:);
                    % N.B. the ancestor of current particle j at time k-1 is given by  B(j)
                    Xcur(row,col,uinds) = Xold(u(1),u(2),uinds) + sigma*randn(1,1,sum(uinds),1);
                end
            end            
        end
    end
    
    % **** WEIGHT COMPUTATION ****
    logW = logW + sum(sum(logtpdf(bsxfun(@minus, Y(:,:,k), Xcur), nu, 1),1),2); % [1 1 N]
    maxlW = max( logW );
    wght = exp( logW - maxlW ); % unnormalised
    Wght = wght/sum(wght);
    ess = 1/(N*sum(Wght.^2,3));
    ess_log(k) = ess*N;
    
    % Compute estimate
    Xhat(:,:,k) = sum(bsxfun(@times, Xcur, Wght),3);
    X2hat(:,:,k) = sum(bsxfun(@times, Xcur.^2, Wght),3);
end