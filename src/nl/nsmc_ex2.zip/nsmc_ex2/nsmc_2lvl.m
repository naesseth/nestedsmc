function [Xhat, X2hat, AltXhat, AltX2hat, ess_outer] = nsmc_2lvl(Y,N,M,par)

% Extract some parameters
d = par.d;
delta = par.delta;
nu = par.nu;
sigma = par.sigma;
T = par.T;

Xold = zeros(d,d,1,N); % N.B. We only keep track of one sample per outer particle

% Output
Xhat = zeros(d,d,T);
X2hat = zeros(d,d,T);
AltXhat = zeros(d,d,T);
AltX2hat = zeros(d,d,T);
ess_outer = zeros(1,T);

%    1
%  2 3 4
%    5
Nv = [-1 0 0 0 1 ; 0 -1 0 1 0]'; % Five neighbours
D = [1 1 0 1 1]'; % Distance to neighbours


% --- k = 1 ---------------------------------------------------------------
% Simulate from prior
Xcur = sigma*randn(d,d,M,N); 

% Evaluate weights
logW = logtpdf(bsxfun(@minus, Y(:,:,1), Xcur), nu, 1); % [d d M N]
maxlW = max( logW, [], 3 ); % We will sum over M first
wght = exp( bsxfun(@minus, logW, maxlW) ); % unnormalised
Wght = bsxfun(@rdivide, wght, sum(wght,3)); % normalised

% Compute RB-estimator
AltXhat_tmp = sum(Xcur.*Wght, 3);
AltX2hat_tmp = sum((Xcur.^2).*Wght, 3);

% Compute normalising constant
logZ = maxlW + log(sum(wght,3)) - log(M); % sum the unnormalised weights
logZ = sum(sum(logZ,1),2); % Sum over spatial dimensions, ==> [1 1 1 N]

% Compute outer PF weights
maxlZ = max( logZ );
zeta = exp( logZ - maxlZ ); % unnormalised
Zeta = zeta/sum(zeta);
ess = 1/(N*sum(Zeta.^2));
ess_outer(1) = ess*N;

% Resample outer PF
A = systematic_resampling(Zeta(:),rand(1));

% "Backward simulation"
% for(i = 1:N)
%     for(col = 1:d)
%         for(row = 1:d)            
%             % There is no spatial dynamics, so the BS simply corresponds to
%             % simulating one particle per statial dimension according to
%             % their importance weights
%             B = catrnd(squeeze(Wght(row,col,:,A(i))));
%             Xold(row,col,1,i) = Xcur(row,col,B,A(i));
%         end
%     end
% end

% Faster implementation of the loop above when ESS(outer) << N
survivors = unique(A);
for(s = survivors')
    ind = A==s;
    for(col = 1:d)
        for(row = 1:d)
            % There is no spatial dynamics, so the BS simply corresponds to
            % simulating one particle per statial dimension according to
            % their importance weights
            B = catrnd(squeeze(Wght(row,col,:,s)),sum(ind));
            Xold(row,col,1,ind) = Xcur(row,col,B,s);
        end
    end
end

% Compute estimate
Xhat(:,:,1) = mean(Xold,4);
X2hat(:,:,1) = mean(Xold.^2,4);
AltXhat(:,:,1) = sum(bsxfun(@times, AltXhat_tmp, Zeta),4);
AltX2hat(:,:,1) = sum(bsxfun(@times, AltX2hat_tmp, Zeta),4);

% --- k > 1 ---------------------------------------------------------------
for(k = 2:T)    
    fprintf('NSMC: %i\n',k);
    % **** PROPAGATION ****
    for(col = 1:d)
        for(row = 1:d)
            % Simulate from prior
            Nvij = Nv + ones(5,1)*[row col]; % 5-neighbourhood
            valid = all(Nvij > 0 & Nvij < d+1,2);
            mixtureprob = 1./(D+delta).*valid; % Mixture probabilities
            mixtureprob = mixtureprob/sum(mixtureprob);
            % Select components (for all particles at once)
            mixturecomp = catrnd(mixtureprob,M*N);
            mixturecomp = reshape(mixturecomp, [M, N]);
            for(i = 1:N) % Loop over outer particles
                for(m = 1:5) % Loop over 5 possible neighbours
                    if(valid(m)) % No point in checking invalid neighbours
                        uinds = mixturecomp(:,i) == m; % These M-particles come from mixture component m (with the same u-coordinates)
                        u = Nvij(m,:);
                        % N.B. the ancestor of current particle j at time k-1 is given by  B(j)
                        Xcur(row,col,uinds,i) = Xold(u(1),u(2),1,i) + sigma*randn(1,1,sum(uinds),1);
                    end
                end
            end
        end
    end
    
    % **** WEIGHT COMPUTATION ****    
    logW = logtpdf(bsxfun(@minus, Y(:,:,k), Xcur), nu, 1); % [d d M N]
    maxlW = max( logW, [], 3 ); % We will sum over M first
    wght = exp( bsxfun(@minus, logW, maxlW) ); % unnormalised
    Wght = bsxfun(@rdivide, wght, sum(wght,3)); % normalised
    
    % Compute RB-estimator
    AltXhat_tmp = sum(Xcur.*Wght, 3);
    AltX2hat_tmp = sum((Xcur.^2).*Wght, 3);
    
    % Compute normalising constant
    logZ = bsxfun(@plus, maxlW, log(sum(wght,3))) - log(M); % sum the unnormalised weights
    logZ = sum(sum(logZ,1),2); % Sum over spatial dimensions, ==> [1 1 1 N]
    
    % Compute outer PF weights
    maxlZ = max( logZ );
    zeta = exp( logZ - maxlZ ); % unnormalised
    Zeta = zeta/sum(zeta);
    ess = 1/(N*sum(Zeta.^2));
    ess_outer(k) = ess*N;
    
    % Resample outer PF
    A = systematic_resampling(Zeta(:),rand(1));
    
    % "Backward simulation"
    survivors = unique(A);
    for(s = survivors')
        ind = A==s;
        for(col = 1:d)
            for(row = 1:d)
                % There is no spatial dynamics, so the BS simply corresponds to
                % simulating one particle per statial dimension according to
                % their importance weights
                B = catrnd(squeeze(Wght(row,col,:,s)),sum(ind));
                Xold(row,col,1,ind) = Xcur(row,col,B,s);
            end
        end
    end    
    
    % Compute estimate
    Xhat(:,:,k) = mean(Xold,4);
    X2hat(:,:,k) = mean(Xold.^2,4);
    AltXhat(:,:,k) = sum(bsxfun(@times, AltXhat_tmp, Zeta),4);
    AltX2hat(:,:,k) = sum(bsxfun(@times, AltX2hat_tmp, Zeta),4);
end