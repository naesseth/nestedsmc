clear;
addpath('./utils');
cd('utils');
mex systematic_resampling.c
cd('..');

%% Setup model
par.d = 32;
par.delta = 1;
par.nu = 10;
par.sigma = 1;
par.T = 100;

[Y,X] = gendata(par);

%% SMC paramters
par.resampling = 3; % systematic
par.ESS_threshold = 0.5;
par.ESS_based = 1;

%%
N = 100;
M = 500;
numRuns = 50;

filename = 'res_T100_N100_M500';
save(filename);

numHats = 2*(2+2+1); % X and X2, and 5 estimates all together
numESS = 3;

d = par.d;
T = par.T;

XX_all = zeros(d,d,T,numHats,numRuns);
ESS_all = zeros(T,numESS,numRuns);

fprintf('N.B. The loop over #runs can be done in parallel with parfor.\n');
%parfor(j = 1:numRuns)
for(j = 1:numRuns)    
    XX = zeros(d,d,T,numHats);
    ESS = zeros(T,numESS);
    
    fprintf('Run %i: Starting NSMC.\n',j);
    tic;
    [Xhat_NSMC,X2hat_NSMC,AltXhat_NSMC,AltX2hat_NSMC,ess_NSMC] = nsmc_2lvl(Y,N,M,par);
    XX(:,:,:,1) = Xhat_NSMC;
    XX(:,:,:,2) = X2hat_NSMC;
    XX(:,:,:,3) = AltXhat_NSMC;
    XX(:,:,:,4) = AltX2hat_NSMC;
    ESS(:,1) = ess_NSMC';
    toc;
    fprintf('Run %i: Starting STPF.\n',j);
    tic;
    [Xhat_STPF,X2hat_STPF,AltXhat_STPF,AltX2hat_STPF,ess_STPF] = stpf(Y,N,M,par);
    XX(:,:,:,5) = Xhat_STPF;
    XX(:,:,:,6) = X2hat_STPF;
    XX(:,:,:,7) = AltXhat_STPF;
    XX(:,:,:,8) = AltX2hat_STPF;
    ESS(:,2) = ess_STPF';    
    toc;
    fprintf('Run %i: Starting PF.\n',j);
    tic;
    [Xhat_PF, X2hat_PF, ess_PF] = bootstrap_pf(Y,M*N,par);
    XX(:,:,:,9) = Xhat_PF;
    XX(:,:,:,10) = X2hat_PF;
    ESS(:,3) = ess_PF';
    toc;
    
    savethese(filename,j,XX,ESS);
    
    % Store
    XX_all(:,:,:,:,j) = XX;
    ESS_all(:,:,j) = ESS;
end

save(filename)