function [Xhat, X2hat, AltXhat, AltX2hat, ess_outer] = stpf(Y,N,M,par)

% Extract some parameters
d = par.d;
delta = par.delta;
nu = par.nu;
sigma = par.sigma;
T = par.T;

Xcur = zeros(d,d,M,N);
Xold = zeros(d,d,M,N);
A0 = repmat( reshape(1:M,[1 1 M]) , [d d 1 N] ); % ancestor indices template
B0 = repmat( (1:M)', [1 N] ); % Ancestor indices to k-1 template
logW = zeros(M,N); % particle weights
logZ = zeros(1,N); % outer particle weights

% Output
Xhat = zeros(d,d,T);
X2hat = zeros(d,d,T);
AltXhat = zeros(d,d,T);
AltX2hat = zeros(d,d,T);
AltXhat_tmp = zeros(d,d,1,N);
AltX2hat_tmp = zeros(d,d,1,N);
ess_outer = zeros(1,T);

%    1
%  2 3 4
%    5
Nv = [-1 0 0 0 1 ; 0 -1 0 1 0]'; % Five neighbours
D = [1 1 0 1 1]'; % Distance to neighbours

resampleTheseM = 1:N;

% --- k = 1 ---------------------------------------------------------------
A = A0; % Ancestor indices for first iteration
for(col = 1:d)
    for(row = 1:d)
        % **** RESAMPLING ****
        if(col > 1 || row > 1)            
            % Resample the inner PFs that fall below threshold
            if(par.ESS_based)
                resampleTheseM = find(essM < par.ESS_threshold);
            end
            for(i = resampleTheseM)
                % ind = resampling(Wght(:,i),par.resampling);
                ind = systematic_resampling(Wght(:,i),rand(1));
                %Xcur(:,:,:,i) = Xcur(:,:,ind,i);
                A(row,col,:,i) = ind;
                % Update normalizing constant for i:th outer PF
                logZ(i) = logZ(i) + maxlW(i) + log(sum(wght(:,i))) - log(M); % sum the unnormalised weights
                logW(:,i) = 0; % Set log-weights to zero after resampling
            end
        end
        
        % **** PROPAGATION ****
        % Simulate from prior
        Xcur(row,col,:,:) = sigma*randn(1,1,M,N);
        
        % **** WEIGHT COMPUTATION ****
        % Compute weights
        logW = logW + logtpdf(Y(row,col,1) - squeeze(Xcur(row,col,:,:)), nu, 1);
        
        maxlW = max( logW, [], 1 );
        wght = exp( bsxfun(@minus, logW, maxlW) ); % unnormalised
        Wght = bsxfun(@rdivide, wght, sum(wght,1)); % normalised
        essM = 1./(M*sum(Wght.^2,1));
                
        % Compute estiamte at each space-step
        AltXhat_tmp(row,col,1,:) =  sum( Xcur(row,col,:,:).*reshape(Wght,[1 1 M N]), 3);
        AltX2hat_tmp(row,col,1,:) = sum( (Xcur(row,col,:,:).^2).*reshape(Wght,[1 1 M N]), 3);
    end
end

% Generate trajectories from ancestors
inds = repmat((1:M)', [1 N]);
for(col = d:-1:1)
    for(row = d:-1:1)        
        for(i = 1:N)
            Xold(row,col,:,i) = Xcur(row,col,inds(:,i),i);
            inds(:,i) = A(row,col,inds(:,i),i);
        end
    end
end

% Update normalizing constant with final weights
logZ = logZ + maxlW + log(sum(wght,1)) - log(M); % sum the unnormalised weights

% Compute outer PF weights
maxlZ = max( logZ );
zeta = exp( logZ - maxlZ ); % unnormalised
Zeta = zeta/sum(zeta);
ess = 1/(N*sum(Zeta.^2));
ess_outer(1) = ess*N;

% Compute estimate
Xhat_tmp = sum( bsxfun(@times, Xold, reshape(Wght, [1 1 M N])), 3); % [d d 1 N]
X2hat_tmp = sum( bsxfun(@times, Xold.^2, reshape(Wght, [1 1 M N])), 3); % [d d 1 N]
Xhat(:,:,1) = sum( bsxfun(@times, Xhat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
X2hat(:,:,1) = sum( bsxfun(@times, X2hat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
AltXhat(:,:,1) = sum( bsxfun(@times, AltXhat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
AltX2hat(:,:,1) = sum( bsxfun(@times, AltX2hat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]

% --- k > 1 ---------------------------------------------------------------
for(k = 2:T)
    fprintf('STPF: %i\n',k);
    A = A0; % Ancestor indices for k:th iteration [d d M N]
    B = B0; % Ancestor indices to k-1 [M N]
    
    % Resample outer PF
    ind = systematic_resampling(Zeta(:),rand(1));
    Xold = Xold(:,:,:,ind);
    logW = logW(:,ind); % We might have non-zero log-weights at the final iteration; retain these
    essM = essM(:,ind);
    logZ = zeros(1,N);

    % Run N inner PFs in parallel
    for(col = 1:d)
        for(row = 1:d)
            % **** RESAMPLING ****
            % Resample the inner PFs that fall below threshold
            if(par.ESS_based)
                resampleTheseM = find(essM < par.ESS_threshold);
            end
            for(i = resampleTheseM)
                % ind = resampling(Wght(:,i),par.resampling);
                ind = systematic_resampling(Wght(:,i),rand(1));
                %Xcur(:,:,:,i) = Xcur(:,:,ind,i);
                A(row,col,:,i) = ind; % Store ancestor indices
                B(:,i) = B(ind,i); % Keep track of ancestors at k-1 since these are used in propagation step
                
                % Update normalizing constant for i:th outer PF
                if(col > 1 || row > 1) % N.B. final weights from k-1 are already accounted for in logZ and used in resampling
                    logZ(i) = logZ(i) + maxlW(i) + log(sum(wght(:,i))) - log(M); % sum the unnormalised weights
                end
                logW(:,i) = 0; % Set log-weights to zero after resampling
            end
            
            % **** PROPAGATION ****
            % Simulate from prior            
            Nvij = Nv + ones(5,1)*[row col]; % 5-neighbourhood
            valid = all(Nvij > 0 & Nvij < d+1,2);
            mixtureprob = 1./(D+delta).*valid; % Mixture probabilities
            mixtureprob = mixtureprob/sum(mixtureprob);
            % Select components (for all particles at once)
            mixturecomp = catrnd(mixtureprob,M*N);
            mixturecomp = reshape(mixturecomp, [M, N]);
            for(i = 1:N) % Loop over outer particles                
                for(m = 1:5) % Loop over 5 possible neighbours
                    if(valid(m)) % No point in checking invalid neighbours
                        uinds = mixturecomp(:,i) == m; % These M-particles come from mixture component m (with the same u-coordinates)
                        u = Nvij(m,:);
                        % N.B. the ancestor of current particle j at time k-1 is given by  B(j)
                        Xcur(row,col,uinds,i) = Xold(u(1),u(2),B(uinds,i),i) + sigma*randn(1,1,sum(uinds),1);
                    end
                end
            end
            
            % **** WEIGHT COMPUTATION ****
            % Compute weights
            logW = logW + logtpdf(Y(row,col,k) - squeeze(Xcur(row,col,:,:)), nu, 1);
            
            maxlW = max( logW, [], 1 );
            wght = exp( bsxfun(@minus, logW, maxlW) ); % unnormalised
            Wght = bsxfun(@rdivide, wght, sum(wght,1)); % normalised
            essM = 1./(M*sum(Wght.^2,1));       
            
            % Compute estiamte at each space-step
            AltXhat_tmp(row,col,1,:) =  sum( Xcur(row,col,:,:).*reshape(Wght,[1 1 M N]), 3);
            AltX2hat_tmp(row,col,1,:) =  sum( (Xcur(row,col,:,:).^2).*reshape(Wght,[1 1 M N]), 3);
        end
    end
        
    % Generate trajectories from ancestors
    inds = repmat((1:M)', [1 N]);
    for(col = d:-1:1)
        for(row = d:-1:1)
            for(i = 1:N)
                Xold(row,col,:,i) = Xcur(row,col,inds(:,i),i);
                inds(:,i) = A(row,col,inds(:,i),i);
            end
        end
    end
    
    % Update normalizing constant with final weights
    logZ = logZ + maxlW + log(sum(wght,1)) - log(M); % sum the unnormalised weights
    
    % Compute outer PF weights
    maxlZ = max( logZ );
    zeta = exp( logZ - maxlZ ); % unnormalised
    Zeta = zeta/sum(zeta);
    ess = 1/(N*sum(Zeta.^2));
    ess_outer(k) = ess*N;
    
    % Compute estimate
    Xhat_tmp = sum( bsxfun(@times, Xold, reshape(Wght, [1 1 M N])), 3); % [d d 1 N]
    X2hat_tmp = sum( bsxfun(@times, Xold.^2, reshape(Wght, [1 1 M N])), 3); % [d d 1 N]
    Xhat(:,:,k) = sum( bsxfun(@times, Xhat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
    X2hat(:,:,k) = sum( bsxfun(@times, X2hat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
    AltXhat(:,:,k) = sum( bsxfun(@times, AltXhat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
    AltX2hat(:,:,k) = sum( bsxfun(@times, AltX2hat_tmp, reshape(Zeta, [1 1 1 N])), 4); % [d d]
end